<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class Sharecertificate extends Model
{
	
}