<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Withdrawshare extends Model
{

}