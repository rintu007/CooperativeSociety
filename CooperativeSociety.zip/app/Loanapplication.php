<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Loanapplication extends Model
{

}