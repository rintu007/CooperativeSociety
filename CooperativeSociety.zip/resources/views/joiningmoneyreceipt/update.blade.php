<h2 class="page-header">Edit Joiningmoneyreceipt</h2>
{!! Form::model($joiningmoneyreceipt,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("joiningmoneyreceipt._form")
{!! Form::close() !!}