<h2 class="page-header">New Joiningmoneyreceipt</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("joiningmoneyreceipt._form")
{!! Form::close() !!}