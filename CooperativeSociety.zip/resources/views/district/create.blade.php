<h2 class="page-header">New District</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("district._form")
{!! Form::close() !!}