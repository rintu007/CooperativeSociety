<h2 class="page-header">Update District</h2>
{!! Form::model($district,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("district._form")
{!! Form::close() !!}