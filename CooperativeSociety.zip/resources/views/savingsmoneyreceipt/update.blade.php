<h2 class="page-header">Edit Loanapplicationmoneyreceipt</h2>
{!! Form::model($loanapplicationmoneyreceipt,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("loanapplicationmoneyreceipt._form")
{!! Form::close() !!}