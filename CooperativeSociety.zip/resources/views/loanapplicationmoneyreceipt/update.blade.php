<h2 class="page-header">Edit Loan Application Money Receipt</h2>
{!! Form::model($loanapplicationmoneyreceipt,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("loanapplicationmoneyreceipt._form")
{!! Form::close() !!}