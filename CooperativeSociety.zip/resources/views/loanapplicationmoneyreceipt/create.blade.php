<h2 class="page-header">New Loan Application Money Receipt</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("loanapplicationmoneyreceipt._form")
{!! Form::close() !!}