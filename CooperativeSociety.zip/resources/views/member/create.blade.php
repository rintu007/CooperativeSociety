<h2 class="page-header">New Member</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("member._form")
{!! Form::close() !!}