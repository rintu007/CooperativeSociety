<h2 class="page-header">New Application Form and Passbook</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("appformandpassbook._form")
{!! Form::close() !!}