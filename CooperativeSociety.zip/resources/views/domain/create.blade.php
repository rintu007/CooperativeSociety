<h2 class="page-header">New Domain</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("domain._form")
{!! Form::close() !!}