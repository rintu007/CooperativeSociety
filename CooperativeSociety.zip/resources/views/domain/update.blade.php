<h2 class="page-header">Update Domain</h2>
{!! Form::model($domain,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("domain._form")
{!! Form::close() !!}