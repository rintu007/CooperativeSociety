Override print preview
