<h2 class="page-header">New Branch</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("brn._form")
{!! Form::close() !!}