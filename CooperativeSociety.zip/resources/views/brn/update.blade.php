<h2 class="page-header">Update Branch</h2>
{!! Form::model($brn,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("brn._form")
{!! Form::close() !!}