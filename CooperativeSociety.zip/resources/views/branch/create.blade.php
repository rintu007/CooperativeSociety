<h2 class="page-header">New Branch</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("branch._form")
{!! Form::close() !!}