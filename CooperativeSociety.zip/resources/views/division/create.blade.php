<h2 class="page-header">New Division</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("division._form")
{!! Form::close() !!}