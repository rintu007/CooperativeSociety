<h2 class="page-header">New Share list</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("share._form")
{!! Form::close() !!}