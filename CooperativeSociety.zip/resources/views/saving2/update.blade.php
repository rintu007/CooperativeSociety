<h2 class="page-header">Edit Saving2</h2>
{!! Form::model($saving2,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("saving2._form")
{!! Form::close() !!}