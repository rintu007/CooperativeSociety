<h2 class="page-header">New Saving2</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("saving2._form")
{!! Form::close() !!}