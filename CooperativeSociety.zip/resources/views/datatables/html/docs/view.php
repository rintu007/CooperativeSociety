@section('demo')
    {!! $html->table() !!}
@endsection

@section('scripts')
    {!! $html->scripts() !!}
@endsection
