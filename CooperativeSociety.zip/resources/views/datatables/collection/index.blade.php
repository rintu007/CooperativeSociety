@extends('app')

@section('content')
    <h1 class="">{!! $title !!}</h1>
@stop