<h2 class="page-header">নতুন ঋণ আবেদন যোগ করুন</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("loan._form")
{!! Form::close() !!}