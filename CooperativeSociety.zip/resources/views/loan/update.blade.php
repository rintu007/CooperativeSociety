<h2 class="page-header">আপডেট ঋণ আবেদন</h2>
{!! Form::model($loan,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("loan._form")
{!! Form::close() !!}