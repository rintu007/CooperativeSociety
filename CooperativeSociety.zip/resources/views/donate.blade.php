<!-- <div class="panel panel-default text-center">
    <div class="panel-heading">
        <h3 class="panel-title">Donations Appreciated</h3>
    </div>
    <div class="panel-body">
        <p>
            {!! App\Services\Donate::quote() !!}
        </p>
        <a href='https://pledgie.com/campaigns/29515'><img alt='Click here to lend your support to: Laravel Datatables and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/29515.png?skin_name=chrome' border='0' ></a>
    </div>
</div>
 -->